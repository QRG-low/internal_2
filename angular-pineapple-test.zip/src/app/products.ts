export interface Product {
  name: String;
  price: number;
  color: String;
  displaySize: number;
  chip: String;
  memory: String;
  deliveryTime: number;
  location: String;
  description: String;
  camera: String;
  releaseYear: number;
  /*id: number;
  name: string;
  price: number;
  description: string;
  */
}

export const products = [
  {
    name: 'pinePhone 13 pro',
    price: 1500,
    color: 'sierrablau',
    displaySize: 6.1,
    chip: 'A15',
    memory: '512GB',
    deliveryTime: 3,
    location: 'Berlin',
    description:
      'Ein deutlich leistungsstärkeres Kamera-System. Ein Display, das so reaktionsschnell ist, dass sich alles ganz neu anfühlt. Der schnellste Smartphone Chip der Welt. Außergewöhnlich robust. Und ein riesiger Sprung bei der Batterielaufzeit.',
    camera: '12 MP Pro Kamera-System',
    releaseYear: 2021,
  },
  {
    name: 'pinePhone 13',
    price: 899,
    color: 'polarstern',
    displaySize: 6.1,
    chip: 'A15',
    memory: '128GB',
    deliveryTime: 3,
    location: 'Berlin',
    description:
      'Ein deutlich leistungsstärkeres Kamera-System. Ein Display, das so reaktionsschnell ist, dass sich alles ganz neu anfühlt. Der schnellste Smartphone Chip der Welt. Außergewöhnlich robust. Und ein riesiger Sprung bei der Batterielaufzeit.',
    camera: '12 MP Zwei-Kamera-System',
    releaseYear: 2021,
  },
  {
    name: 'pinePhone 12',
    price: 799,
    color: 'violett',
    displaySize: 6.1,
    chip: 'A14',
    memory: '64GB',
    deliveryTime: 3,
    location: 'Berlin',
    description:
      'Ein extrem leistungsstarker Chip. 5G Geschwindigkeit. Ein fortschrittliches Zwei-Kamera-System. Eine Ceramic Shield Vorderseite, die härter ist als jedes Smartphone Glas. Und ein helles, beeindruckendes OLED Display. Das pinePhone 12 hat alles.',
    camera: '12 MP Zwei-Kamera-System',
    releaseYear: 2020,
  },
  {
    name: 'pinePad pro',
    price: 1209,
    color: 'spacegrau',
    displaySize: 11,
    chip: 'M1',
    memory: '512GB',
    deliveryTime: 4,
    location: 'Hamburg',
    description:
      'Das ultimative pinePad Erlebnis. Jetzt mit bahnbrechender M1 Performance, einem faszinierenden XDR Display und unglaublich schnellem 5G. Schnall dich besser an.',
    camera: 'Pro Kamerasystem mit Weitwinkel- und Ultraweitwinkel Objektiv',
    releaseYear: 2020,
  },

  {
    name: 'pinePad Air',
    price: 819,
    color: 'green',
    displaySize: 10.9,
    chip: 'A14 Bionic',
    memory: '256GB',
    deliveryTime: 4,
    location: 'Hamburg',
    description:
      'Das pinePad Air kann mehr als ein Computer. Dabei fühlt sich alles einfacher an, fast wie Magie. Und mit mehr Funktionen und Möglichkeiten ist es jetzt vielseitiger als je zuvor.',
    camera: '12 MP Kamera mit Weitwinkel objektiv',
    releaseYear: 2019,
  },
  {
    name: 'pinePad mini',
    price: 549,
    color: 'rose',
    displaySize: 8.3,
    chip: 'A15 Bionic',
    memory: '64GB',
    deliveryTime: 4,
    location: 'Hamburg',
    description:
      'Neues All-Screen Design. Leistungsstarker A15 Bionic Chip. Superschnelles 5G. Unterstützung für den Apple Pencil. Jetzt in vier großartigen Farben. Ein Gerät wie kein anderes.',
    camera: '12 MP Weitwinkel-Kamera',
    releaseYear: 2018,
  },
  {
    name: 'pineBook Air',
    price: 1399,
    color: 'weiß',
    displaySize: 13.3,
    chip: 'M1',
    memory: '512GB',
    deliveryTime: 5,
    location: 'Hannover',
    description:
      'Pinepple M1 Chip mit 8‑Core CPU und 8‑Core GPU 512 GB Speicherplatz.',
    camera: '720p FaceTime HD Kamera',
    releaseYear: 2020,
  },
  {
    name: 'pineBook Pro 13',
    price: 1679,
    color: 'silber',
    displaySize: 13.3,
    chip: 'M1',
    memory: '512GB',
    deliveryTime: 5,
    location: 'Hannover',
    description:
      'Pineapple M1 Chip mit 8‑Core CPU und 8‑Core GPU 512 GB SSD Speicher.',
    camera: '720p FaceTime HD Kamera',
    releaseYear: 2021,
  },
  {
    name: 'pineBook Pro 14',
    price: 2749,
    color: 'gold',
    displaySize: 14.2,
    chip: 'M1 Pro',
    memory: '1TB',
    deliveryTime: 5,
    location: 'Hannover',
    description:
      '10‑Core CPU 16‑Core GPU 16 GB gemeinsamer Arbeitsspeicher 1 TB SSD Speicher.',
    camera: '1080p FaceTime HD Kamera',
    releaseYear: 2021,
  },
  {
    name: 'pineBook Pro 16',
    price: 3849,
    color: 'weiß',
    displaySize: 16.2,
    chip: 'M1 Max',
    memory: '1TB',
    deliveryTime: 5,
    location: 'Hannover',
    description:
      '10‑Core CPU 32‑Core GPU 32 GB gemeinsamer Arbeitsspeicher 1 TB SSD Speicher.',
    camera: '1080p FaceTime HD Kamera',
    releaseYear: 2021,
  },
  /*{
    id: 1,
    name: 'Phone XL',
    price: 799,
    description: 'A large phone with one of the best screens'
  },
  {
    id: 2,
    name: 'Phone Mini',
    price: 699,
    description: 'A great phone with one of the best cameras'
  },
  {
    id: 3,
    name: 'Phone Standard',
    price: 299,
    description: ''
  }*/
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
